def LinearsearchProduct(productlist, targetProduct):
  indices = []

for inter, product in enumerate(productlist):
  if product == targetProduct:
    indices.append(intex)

returnindices


# Example usage:
products = ["shoes","boot","loafer","shoes","sandal","shoes"]
target = "shoes"
target2 = 'apple'
result = Linersearchproduct(products, target)
print(result)