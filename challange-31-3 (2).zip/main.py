def LinearsearchProduct(productlist, targetProduct):
  indices = []

for intex, product in enumerate(productlist):
  if product == targetProduct:
    indices.append(intex)

return indices


# Example usage:
products = ["shoes","boot","loafer","shoes","sandal","shoes"]
target = "shoes"
result = linersearchproduct(products,target)
if product == targetProduct:
  indices.append(index)

return indices


(varlable) products: list[str]
products = ["shoes","boot","loafer""shoes","sandal","shoes"]
target = "shoes"
result = Linersearchproduct(products, target)
print(result)